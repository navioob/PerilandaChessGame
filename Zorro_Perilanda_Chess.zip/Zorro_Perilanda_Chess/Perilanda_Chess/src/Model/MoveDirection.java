package Model;

/**
 * This enum class contains types Moving Direction for Trident and Advancer
 *
 * @author Boo Ee Kein Ivan
 */

public enum MoveDirection {
    FORWARD,BACKWARD
}
